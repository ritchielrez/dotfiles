require('plugins')
require('opts')
require('keymaps')


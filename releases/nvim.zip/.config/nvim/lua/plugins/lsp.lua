require'lspconfig'.pyright.setup{}
